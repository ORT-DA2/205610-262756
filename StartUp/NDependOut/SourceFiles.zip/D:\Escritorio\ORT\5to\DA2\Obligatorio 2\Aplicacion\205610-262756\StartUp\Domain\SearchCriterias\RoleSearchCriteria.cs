﻿
namespace StartUp.Domain.SearchCriterias
{
    public class RoleSearchCriteria
    {
        public string? Permission { get; set; }
    }
}
