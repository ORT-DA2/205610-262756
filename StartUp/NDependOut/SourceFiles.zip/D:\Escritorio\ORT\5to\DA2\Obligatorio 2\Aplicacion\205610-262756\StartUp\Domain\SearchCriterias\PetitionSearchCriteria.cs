﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Text;

namespace StartUp.Domain.SearchCriterias
{
    public class PetitionSearchCriteria
    {
        public string? MedicineCode { get; set; }
    }
}
