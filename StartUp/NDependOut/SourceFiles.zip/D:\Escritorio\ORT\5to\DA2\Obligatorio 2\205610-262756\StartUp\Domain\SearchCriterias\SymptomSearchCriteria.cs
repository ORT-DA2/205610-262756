
namespace StartUp.Domain.SearchCriterias
{

    public class SymptomSearchCriteria
    {
        public string? SymptomDescription { get; set; }
    }
}