﻿

namespace StartUp.ModelsExporter
{
    public class ModelExporter
    {
        public string RouteName { get; set; }
        public string Format { get; set; }
    }
}
